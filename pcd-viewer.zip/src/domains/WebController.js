import { WebRenderer } from "./WebRenderer";

export class WebController {
    constructor(container) {
        this.renderer = new WebRenderer(container);
    }

    init(controllerType = "orbit") {
        this.renderer.init(controllerType);
        this.renderer.animate();
    }

    addPCD(name, pcd) {
        this.renderer.addPCD(name, pcd.getPoints());
    }

    dispose() {
        this.renderer.dispose();
    }
}
