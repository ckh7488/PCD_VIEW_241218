import React, { useRef, useEffect, useState } from "react";
import { WebController } from "../../domains/WebController";
import { readPCDFile } from "../../domains/PCDFileReader";

const WebViewer = () => {
    const containerRef = useRef(null);
    const controllerRef = useRef(null);
    const [isDragging, setIsDragging] = useState(false);
    const dragCounter = useRef(0); // 드래그 상태 추적

    useEffect(() => {
        if (containerRef.current) {
            const controller = new WebController(containerRef.current);
            controller.init("orbit");
            controllerRef.current = controller;

            return () => controller.dispose();
        }
    }, []);

    const handleDragEnter = (event) => {
        event.preventDefault();
        event.stopPropagation();
        dragCounter.current += 1;
        setIsDragging(true);
    };

    const handleDragOver = (event) => {
        event.preventDefault();
        event.stopPropagation();
    };

    const handleDragLeave = (event) => {
        event.preventDefault();
        event.stopPropagation();
        dragCounter.current -= 1;
        if (dragCounter.current === 0) {
            setIsDragging(false);
        }
    };

    const handleDrop = async (event) => {
        event.preventDefault();
        event.stopPropagation();
        setIsDragging(false);
        dragCounter.current = 0;

        const files = Array.from(event.dataTransfer.files);
        const pcdFiles = files.filter((file) => file.name.endsWith(".pcd"));

        for (const file of pcdFiles) {
            try {
                const pcd = await readPCDFile(file);
                controllerRef.current.addPCD(file.name, pcd);
            } catch (error) {
                console.error("Failed to read PCD file:", error);
            }
        }
    };

    return (
        <div
            ref={containerRef}
            style={{ width: "100%", height: "100vh", position: "relative" }}
            onDragEnter={handleDragEnter}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
            onDragLeave={handleDragLeave}
        >
            {isDragging && (
                <div className="overlay">
                    <p>Drag and Drop files here</p>
                </div>
            )}
        </div>
    );
};

export default WebViewer;
